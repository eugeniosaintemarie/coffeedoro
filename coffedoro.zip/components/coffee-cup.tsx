import { useEffect, useRef } from "react"
import type { FC } from "react"

interface CoffeeCupProps {
  percentage: number;
  isWorking: boolean;
  isActive: boolean;
}

// Componente que muestra una taza de café con nivel según el porcentaje
const CoffeeCup: FC<CoffeeCupProps> = ({ percentage, isWorking, isActive }) => {
  const cupRef = useRef<HTMLDivElement>(null)
  
  // Calculamos la altura del café según el porcentaje
  // En modo trabajo, el café debe disminuir (100% al inicio, 0% al final)
  // En modo descanso, el café debe aumentar (0% al inicio, 100% al final)
  const coffeeLevel = isWorking ? 100 - percentage : percentage
  
  // Calculamos la altura del café en píxeles (130px es la altura máxima)
  const coffeeHeight = (coffeeLevel * 130 / 100)

  // Aplicamos la lógica para el patrón de fondo (130px es vacío, 0px es lleno)
  const backgroundPosition = `0 ${coffeeHeight}px`
  
  // Comentamos esta parte para evitar conflictos con la animación de JavaScript
  // useEffect(() => {
  //   if (cupRef.current) {
  //     cupRef.current.style.setProperty('--coffee-height', `${coffeeHeight}px`)
  //   }
  // }, [coffeeHeight])
  
  return (
    <div className="flex items-center justify-center my-8">
      <div 
        ref={cupRef}
        className="cup"
        style={{
          backgroundPosition: backgroundPosition
        }}
      >
        {isActive && (
          <>
            <span className="steam"></span>
            <span className="steam"></span>
            <span className="steam"></span>
          </>
        )}
        <div className="cup-handle"></div>
      </div>
    </div>
  )
}

export default CoffeeCup

